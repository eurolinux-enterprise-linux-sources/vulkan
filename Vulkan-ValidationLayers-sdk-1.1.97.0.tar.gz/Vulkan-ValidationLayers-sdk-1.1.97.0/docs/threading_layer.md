# VK\_LAYER\_GOOGLE\_threading

The `VK_LAYER_GOOGLE_threading` layer checks multi-threading of API calls for validity.  Checks performed by this layer include ensuring that only one thread at a time uses an object in free-threaded API calls.
